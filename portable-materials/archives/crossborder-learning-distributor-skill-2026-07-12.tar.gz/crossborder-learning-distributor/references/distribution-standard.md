# Distribution Standard

## Role Update Files

Each role folder should contain:

- `_最新更新.md`: newest published learning update for quick loading.
- `_索引.md`: all distributed skill packs in reverse chronological order.

## Distribution Record

Save one record per learning cycle under:

```text
/Users/admin/Desktop/创收/跨境/知识库/分发记录
```

Required fields:

- Time
- Topic
- Source
- Knowledge note
- Strategy file
- Data file
- Operations file
- Visual file
- Next actions

## Skill-Pack Quality Bar

Each role file must include:

- Source
- Core rules
- Step-by-step workflow
- Tables/templates where useful
- Risk checks
- Output template


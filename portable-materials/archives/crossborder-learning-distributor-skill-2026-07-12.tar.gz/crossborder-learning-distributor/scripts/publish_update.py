#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path


ROOT = Path("/Users/admin/Desktop/创收/跨境")
KB = ROOT / "知识库"
ROLE_DIRS = {
    "strategy": ROOT / "技能包" / "策略（选品）能手",
    "data": ROOT / "技能包" / "数据能手",
    "operations": ROOT / "技能包" / "运营能手",
    "visual": ROOT / "技能包" / "视觉能手",
}
ROLE_NAMES = {
    "strategy": "策略（选品）能手",
    "data": "数据能手",
    "operations": "运营能手",
    "visual": "视觉能手",
}


def rel(path: str) -> str:
    p = Path(path)
    try:
        return str(p.relative_to(ROOT))
    except ValueError:
        return str(p)


def link(path: str) -> str:
    p = Path(path)
    return f"[{p.name}]({p})"


def prepend(path: Path, content: str) -> None:
    old = path.read_text(encoding="utf-8") if path.exists() else ""
    path.write_text(content.rstrip() + "\n\n" + old.lstrip(), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--topic", required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--knowledge-note", required=True)
    parser.add_argument("--strategy", required=True)
    parser.add_argument("--data", required=True)
    parser.add_argument("--operations", required=True)
    parser.add_argument("--visual", required=True)
    args = parser.parse_args()

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    files = {
        "strategy": args.strategy,
        "data": args.data,
        "operations": args.operations,
        "visual": args.visual,
    }

    for key, folder in ROLE_DIRS.items():
        folder.mkdir(parents=True, exist_ok=True)
        latest = folder / "_最新更新.md"
        index = folder / "_索引.md"
        role_file = files[key]
        latest.write_text(
            "\n".join(
                [
                    f"# {ROLE_NAMES[key]} 最新更新",
                    "",
                    f"- 时间：{now}",
                    f"- 主题：{args.topic}",
                    f"- 来源：{args.source}",
                    f"- 总库笔记：{link(args.knowledge_note)}",
                    f"- 本角色技能包：{link(role_file)}",
                    "",
                    "下次该角色 Codex 开始工作时，先读取本文件和本角色技能包。",
                    "",
                ]
            ),
            encoding="utf-8",
        )
        prepend(
            index,
            "\n".join(
                [
                    f"## {now} - {args.topic}",
                    "",
                    f"- 来源：{args.source}",
                    f"- 总库：`{rel(args.knowledge_note)}`",
                    f"- 技能包：`{rel(role_file)}`",
                ]
            ),
        )

    record_dir = KB / "分发记录"
    record_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
    record = record_dir / f"{stamp}-{args.topic.replace('/', '-')}.md"
    record.write_text(
        "\n".join(
            [
                f"# 分发记录：{args.topic}",
                "",
                f"- 时间：{now}",
                f"- 来源：{args.source}",
                f"- 总库笔记：`{rel(args.knowledge_note)}`",
                f"- 策略：`{rel(args.strategy)}`",
                f"- 数据：`{rel(args.data)}`",
                f"- 运营：`{rel(args.operations)}`",
                f"- 视觉：`{rel(args.visual)}`",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(record)


if __name__ == "__main__":
    main()

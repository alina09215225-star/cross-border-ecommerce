---
name: crossborder-learning-distributor
description: "Cross-border ecommerce learning workflow for Codex. Use when learning Bilibili, marketplace, ecommerce, product research, operations, data, or visual-production materials for the user's cross-border business, especially when content must be deposited into `/Users/admin/Desktop/创收/跨境/知识库` and distributed to the four role assistants: 策略（选品）能手, 数据能手, 运营能手, and 视觉能手."
---

# Crossborder Learning Distributor

## Core Rule

Do not stop at a summary. Every learned source must become:

1. A knowledge-base note.
2. A reusable method or SOP when applicable.
3. Four role-specific updates.
4. A distribution record.
5. Updated role indexes so other Codex instances can find the latest content.

## Paths

Knowledge base:

```text
/Users/admin/Desktop/创收/跨境/知识库
```

Role skill-pack folders:

```text
/Users/admin/Desktop/创收/跨境/技能包/策略（选品）能手
/Users/admin/Desktop/创收/跨境/技能包/数据能手
/Users/admin/Desktop/创收/跨境/技能包/运营能手
/Users/admin/Desktop/创收/跨境/技能包/视觉能手
```

## Workflow

1. Learn the source.
   - Prefer transcript/subtitles for courses.
   - If only video/audio exists, extract audio and transcribe.
   - Do not invent details when source content is unavailable.

2. Write the knowledge-base note.
   - Save under `知识库/课程学习` for courses.
   - Save under `知识库/方法论` for reusable methods.

3. Split by role.
   - Strategy: selection logic, opportunity, scoring, entry/exit criteria.
   - Data: sources, fields, sampling, validation, dashboards, reports.
   - Operations: listing, fulfillment, inventory, promotions, customer service, returns.
   - Visual: image/video/A+ requirements, templates, scripts, risk checks.

4. Publish updates.
   - Create or update versioned role files.
   - Run `scripts/publish_update.py` to update role indexes and latest-update files.
   - Write one distribution record under `知识库/分发记录`.

5. Keep versions.
   - Prefer `v2`, `v3`, etc. instead of overwriting prior files.
   - If correcting a mistake, update the newest version and note the correction in the distribution record.

## Publishing Command

After writing new role files, run:

```bash
python3 /Users/admin/.codex/skills/crossborder-learning-distributor/scripts/publish_update.py \
  --topic "主题" \
  --source "来源" \
  --knowledge-note "/absolute/path/to/knowledge-note.md" \
  --strategy "/absolute/path/to/strategy.md" \
  --data "/absolute/path/to/data.md" \
  --operations "/absolute/path/to/operations.md" \
  --visual "/absolute/path/to/visual.md"
```

If `python3` is broken on this Mac, use:

```bash
/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3
```

## Other Codex Usage

Tell other Codex instances to use this skill and read:

```text
/Users/admin/.codex/skills/crossborder-learning-distributor/SKILL.md
```

They should then check each role folder's:

```text
_最新更新.md
_索引.md
```
